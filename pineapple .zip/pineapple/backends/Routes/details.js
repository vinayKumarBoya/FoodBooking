const  router = require('express').Router();
router.post('/signin', ensureAuthenticated, user);